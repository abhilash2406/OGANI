import React from 'react';
import styled from 'styled-components';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
// import { LinkContainer } from 'react-router-bootstrap';
// import img from '../Images/HomeImg.webp';

// import { US } from 'country-flag-icons/react/3x2';
// import CountryDropdown from 'country-dropdown-with-flags-for-react';

// style for main header section

const Hedder = styled.div`
  margin-bottom: 40px;
`;
const Topheadersection = styled.div`
  width: 100%;
  height: 50px;
  padding: 0 80px 0 80px;
  background-color: #f5f5f5;
  display: flex;
  flex-direction: row;
`;

// style for header email
const Headeremail = styled.p`
  margin: 15px 0 5px 6px;
  font-size: 13px;
  color: #000;
  font-weight: 400;
`;
const HeaderEmailtxt = styled.span`
  margin-right: 6px;
`;

const ShippingDetails = styled.p`
  margin: 15px 0 5px 6px;
  font-size: 13px;
  color: #000;
  font-weight: 400;
  margin-left: 30px;
`;

const Bar = styled.div`
  border-left: 1px rgb(218, 201, 201) solid;
  height: 16px;
  margin: 15px 0 0 15px;
  font-weight: 100;
`;

// style for social media icons
const SocialmediaIcons = styled.div`
  margin: 12px 0 5px 360px;
`;
const SocialmediaIconsspan = styled.span`
  margin: 0 0 0 20px;
  font-size: 14px;
  color: #000;
`;

// style for language select drop down list
const LangSelect = styled.select`
  border: none;
  background-color: #f5f5f5;
  margin-left: 54px;
  font-size: 13px;
  font-weight: 400;
  height: 30px;
  margin-top: 10px;
  outline: none;
`;

//style for drop down list option
const LangSelectOptions = styled.option`
  width: 20px;
  height: 20px;
  font-size: 12px;
  color: #000;
  background-color: #fff;
  font-weight: 400;
`;
const LoginButton = styled.p`
  font-weight: 300;
  font-size: 13px;
  margin: 15px 0 0 40px;
`;

const LoginButtonTxt = styled.span`
  margin: 0 8px 0 0;
`;

const HeadermiddleSection = styled.div`
  height: 75px;
  background-color: #fff;
  margin: 0 80px 0 80px;
  display: flex;
  flex-direction: row;
`;

const LogoImageContainer = styled.div`
  width: 144px;
  height: 60px;
  margin-top: 6px;
`;

const LogoImage = styled.img`
  width: 80%;
  height: 50px;
  margin-top: 10px;
`;

const HeaderMidColumn2 = styled.div`
  display: flex;
  flex-direction: row;
  
  width: 56%;
`;

const HeaderMidColumn3 = styled.div`
  display: flex;
`;

const HeaderCart = styled.div`
  display: flex;
  flex-direction: row;
  margin-top: 25px;
  padding-left: 72px;
`;

const ShoppingCartUl = styled.ul`
  display: inline-block;
  margin-top: 5px;
  margin-left: 55px;
`;

const ShoppingCartLi = styled.li`
  list-style: none;
  display: inline-block;
  margin-right: 15px;
`;

const Cartspan = styled.span`
  height: 15px;
  width: 15px;
  background: #7fad39;
  font-size: 13px;
  color: #ffffff;
  line-height: 13px;
  text-align: center;
  font-weight: 700;
  display: inline-block;
  border-radius: 50%;
  top: 0;
  right: -12px;
`;
const CartHeadPrice = styled.div`
  display: inline-block;
  font-size: 14px;
  color: #6f6f6f;
  margin-top: 30px;
  margin-left: 10px;
`;

const HeaderCartPricespan = styled.span`
  color: #252525;
  font-weight: 700;
`;

const HeaderBottomSection = styled.div`
  height: 50px;
  /* background-color: yellow; */
  margin: 10px 80px 0 80px;
  display: flex;
  flex-direction: row;
`;

const CategoryListDiv = styled.div`
  background: #7fad39;
  /* position: relative; */
  border-radius: 0;
  padding: 10px 25px 10px 40px;
  cursor: pointer;
  border: none;
  width: 260px;
`;

const CategoryList = styled.ul`
  border: 1px solid #ebebeb;
  padding-left: 40px;
  padding-top: 10px;
  padding-bottom: 12px;
  width: 260px;
`;

const CategoryListItems = styled.a`
  font-size: 16px;
  color: #1c1c1c;
  line-height: 39px;
  display: block;
`;

const SearchOptions = styled.div`
  display: flex;
  width: 580px;
  height: 50px;
  margin-left: 40px;
  border: 1px solid #ebebeb;
`;

const SearchInPut = styled.input`
  width: 70%;
  border: none;
  outline: none;
  font-size: 14px;
  color: #b2b2b2;
  padding-left: 20px;
  margin-left: 30px;
`;

const SearchButton = styled.a`
  font-size: 15px;
  color: #ffffff;
  font-weight: 800;
  width: 24%;
  padding: 12px 0 0 22px;
  text-decoration: none;
  background: #7fad39;
  border: none;
`;

const Contact = styled.div`
  margin-left: 40px;
  display: flex;
  flex-direction: row;
`;
const PhoneIcon = styled.div`
  font-size: 18px;
  color: #7fad39;
  height: 50px;
  width: 50px;
  background: #f5f5f5;
  line-height: 50px;
  text-align: center;
  border-radius: 50%;
  margin-right: 20px;
`;

const PhnNo = styled.h5`
  color: #1c1c1c;
  font-weight: 900;
  margin-bottom: 5px;
  font-size: 16px;
`;

const PhnNotextSpan = styled.span`
  font-size: 14px;
  color: #6f6f6f;
`;

const Header = () => {
  return (
    //main container
    <Hedder>
      {/* top header section  */}
      <Topheadersection>
        <Headeremail className="header_email">
          <HeaderEmailtxt className="fa-solid fa-envelope"></HeaderEmailtxt>
          hello@colorlib.com
        </Headeremail>
        <Bar></Bar>
        <ShippingDetails>Free Shipping for all Order of $99</ShippingDetails>
        <SocialmediaIcons>
          <SocialmediaIconsspan className="fa-brands fa-facebook-f"></SocialmediaIconsspan>
          <SocialmediaIconsspan className="fa-brands fa-twitter"></SocialmediaIconsspan>
          <SocialmediaIconsspan className="fa-brands fa-linkedin-in"></SocialmediaIconsspan>
          <SocialmediaIconsspan className="fa-brands fa-pinterest-p"></SocialmediaIconsspan>
        </SocialmediaIcons>
        <Bar></Bar>
        {/* <CountryDropdown  id="UNIQUE_ID" className='YOUR_CSS_CLASS' preferredCountries={['gb', 'us']}  value="" ></CountryDropdown>  */}
        <LangSelect>
          <LangSelectOptions defaultValue>English</LangSelectOptions>
          <LangSelectOptions>Spanish</LangSelectOptions>
        </LangSelect>
        <Bar></Bar>
        <LoginButton>
          <LoginButtonTxt className="fa-solid fa-user"></LoginButtonTxt>Login
        </LoginButton>
      </Topheadersection>

      {/* Middle Header Section  */}
      <HeadermiddleSection>
        <LogoImageContainer>
          <LogoImage src={require('../Images/logo.png.webp')}></LogoImage>
        </LogoImageContainer>
        <HeaderMidColumn2>
          <Navbar bg="white~" variant="light" style={{ marginLeft: '111px' }}>
            <Nav className="me-auto" style={{ marginTop: '15px' }}>
              <Nav.Link
                as={Link}
                to="/"
                style={{
                  fontSize: '15px',
                  marginLeft: '40px',
                  fontWeight: 600,
                  color: 'black',
                }}
              >
                HOME
              </Nav.Link>
              <Nav.Link
                as={Link}
                to="/shop"
                style={{
                  fontSize: '15px',
                  marginLeft: '40px',
                  fontWeight: 600,
                  color: 'black',
                }}
              >
                SHOP
              </Nav.Link>
              <Nav.Link
                href="#pricing"
                style={{
                  fontSize: '15px',
                  marginLeft: '40px',
                  fontWeight: 600,
                  color: 'black',
                }}
              >
                PAGES
              </Nav.Link>
              <Nav.Link
                href="#pricing"
                style={{
                  fontSize: '15px',
                  marginLeft: '40px',
                  fontWeight: 600,
                  color: 'black',
                }}
              >
                BLOG
              </Nav.Link>
              <Nav.Link
                as={Link}
                to="/contact"
                style={{
                  fontSize: '15px',
                  marginLeft: '40px',
                  fontWeight: 600,
                  color: 'black',
                }}
              >
                CONTACT
              </Nav.Link>
            </Nav>
          </Navbar>
        </HeaderMidColumn2>
        <HeaderMidColumn3>
          <HeaderCart>
            <ShoppingCartUl>
              <ShoppingCartLi>
                <a href="abc.com">
                  <i
                    className="fa-solid fa-heart"
                    style={{ fontSize: '18px', color: '#1c1c1c' }}
                  ></i>
                  <Cartspan>1</Cartspan>
                </a>
              </ShoppingCartLi>
              <ShoppingCartLi>
                <a href="cde.com">
                  <i
                    className="fa-solid fa-bag-shopping"
                    style={{ fontSize: '18px', color: '#1c1c1c' }}
                  ></i>
                  <Cartspan>2</Cartspan>
                </a>
              </ShoppingCartLi>
            </ShoppingCartUl>
          </HeaderCart>
          <CartHeadPrice>
            Item:
            <HeaderCartPricespan>$150.00</HeaderCartPricespan>
          </CartHeadPrice>
        </HeaderMidColumn3>
      </HeadermiddleSection>

      {/* header bottom section  */}
      <HeaderBottomSection>
        <div>
          <CategoryListDiv
            className="btn btn-warning dropdown"
            type="button"
            id="dropdownMenuButton1"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            <i
              className=" fa fa-bars"
              style={{
                fontSize: '16px',
                color: '#ffffff',
                marginRight: '10px',
              }}
            ></i>
            <span
              style={{
                fontSize: '17px',
                fontWeight: 900,
                color: '#ffffff',
              }}
            >
             All  Departments
            </span>
            <span
              style={{ fontSize: '18px', marginLeft: '12px', color: '#fff' }}
            >
              &#8964;
            </span>
          </CategoryListDiv>
          <CategoryList
            className="dropdown-menu"
            aria-labelledby="dropdownMenuButton1"
          >
            <li>
              <CategoryListItems className="dropdown-item" href="asw.com">
                Fresh Meat
              </CategoryListItems>
            </li>
            <li>
              <CategoryListItems className="dropdown-item" href="fds.com">
                Vegetables
              </CategoryListItems>
            </li>
            <li>
              <CategoryListItems className="dropdown-item" href="wewe.com">
                Fruits & Nuts
              </CategoryListItems>
            </li>
            <li>
              <CategoryListItems className="dropdown-item" href="wewe.com">
                Ocean Foods
              </CategoryListItems>
            </li>
            <li>
              <CategoryListItems className="dropdown-item" href="wewe.com">
                OatMeals
              </CategoryListItems>
            </li>
            <li>
              <CategoryListItems className="dropdown-item" href="wewe.com">
                Butter & Eggs
              </CategoryListItems>
            </li>
          </CategoryList>
        </div>
        <SearchOptions>
          <button
            className="btn  dropdown-toggle"
            type="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
            style={{ fontWeight: 700 }}
          >
            All categories
          </button>
          <div
            className="dropdown-menu"
            aria-labelledby="dropdownMenuButton"
            style={{ fontWeight: 500 }}
          >
            <a className="dropdown-item" href="dd.com">
              Action
            </a>
            <a className="dropdown-item" href="dsa.com">
              Another action
            </a>
            <a className="dropdown-item" href="dgyd.com">
              Something else here
            </a>
          </div>
          <Bar></Bar>
          <SearchInPut
            type="text"
            placeholder="What do you need?"
          ></SearchInPut>
          <SearchButton> SEARCH</SearchButton>
        </SearchOptions>
        <Contact>
          <PhoneIcon>
            <i className="fa-solid fa-phone" style={{ fontWeight: 800 }}></i>
          </PhoneIcon>
          <div className="phoneNo">
            <PhnNo>+65 11.188.888</PhnNo>
            <PhnNotextSpan>support 24/7 time</PhnNotextSpan>
          </div>
        </Contact>
      </HeaderBottomSection>
    </Hedder>
  );
};
export default Header;
