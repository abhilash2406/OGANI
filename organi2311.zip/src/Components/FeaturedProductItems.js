import React from 'react';
import styled from 'styled-components';
import products from '../Components/ProductList';

const FeaturedProductItemWrapper = styled.div`
  width: 263px;
  height: 335px;
  display: flex;
  margin-bottom: 50px;
  flex-direction: column;

  &:hover #list {
    display: block;
  }
`;

const FeaturedItem = styled.div`
  width: 100%;
  background: url(${(props) => props.background}) no-repeat top center;
  height: 270px;
`;

const FitemTxt = styled.div`
  text-align: center;
  padding-top: 15px;
`;

const FitemTxth6 = styled.h6`
  margin-bottom: 10px;
  font-size: 16px;
`;
const FitemTxthLink = styled.a`
  color: #252525;
  text-decoration: none;
  font-weight: 400;
`;

const FitemTxth5 = styled.h5`
  color: #252525;
  font-weight: 900;
`;

const FeaturedItemUl = styled.ul`
  width: 100%;
  padding: 0;
  margin-top: 212px;
  text-align: center;
  -webkit-transition: all, 0.5s;
  -moz-transition: all, 0.5s;
  -ms-transition: all, 0.5s;
  -o-transition: all, 0.5s;
  transition: all, 0.5s;
  display: none;
`;

const FeaturedItemli = styled.li`
  list-style: none;
  display: inline-block;
  margin-right: 6px;
`;

const FeaturedItemA = styled.a`
  font-size: 16px;
  color: #1c1c1c;
  height: 40px;
  width: 40px;
  line-height: 40px;
  text-align: center;
  border: 1px solid #ebebeb;
  background: #ffffff;
  display: block;
  border-radius: 50%;
  transition: all, 0.5s;
`;

const Lspan = styled.i`
  color: black;
`;

const FeaturedProductItems = (props) => {
  const productData = products.map((item) => {
    return (
      <FeaturedProductItemWrapper key={item.id}>
        <FeaturedItem background={item.image}>
          <FeaturedItemUl id="list">
            <FeaturedItemli>
              <FeaturedItemA>
                <Lspan className="fa-sharp fa-solid fa-heart"></Lspan>
              </FeaturedItemA>
            </FeaturedItemli>
            <FeaturedItemli>
              <FeaturedItemA>
                <i className="fa-solid fa-retweet"></i>
              </FeaturedItemA>
            </FeaturedItemli>
            <FeaturedItemli>
              <FeaturedItemA>
                <i className="fa-sharp fa-solid fa-cart-shopping"></i>
              </FeaturedItemA>
            </FeaturedItemli>
          </FeaturedItemUl>
        </FeaturedItem>
        <FitemTxt>
          <FitemTxth6>
            <FitemTxthLink>{item.name}</FitemTxthLink>
          </FitemTxth6>
          <FitemTxth5> ${item.price}</FitemTxth5>
        </FitemTxt>
      </FeaturedProductItemWrapper>
    );
  });
  return (
    <div className="d-flex flex-wrap  align-content-start justify-content-between">
      {productData}
    </div>
  );
};
export default FeaturedProductItems;
